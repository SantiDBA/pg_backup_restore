--
-- PostgreSQL database dump
--

\restrict Ilhv5fbtvYLkCSY5yUihe2V8CHar1HxJEAAMc0CLXhihLnNdjbU6YbA25OPoYCW

-- Dumped from database version 16.11 (Homebrew)
-- Dumped by pg_dump version 16.11 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: demo_schema_1; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA demo_schema_1;


ALTER SCHEMA demo_schema_1 OWNER TO postgres;

--
-- Name: demo_schema_2; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA demo_schema_2;


ALTER SCHEMA demo_schema_2 OWNER TO postgres;

--
-- Name: demo_schema_3; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA demo_schema_3;


ALTER SCHEMA demo_schema_3 OWNER TO postgres;

--
-- Name: demo_schema_4; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA demo_schema_4;


ALTER SCHEMA demo_schema_4 OWNER TO postgres;

--
-- Name: file_fdw; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS file_fdw WITH SCHEMA public;


--
-- Name: EXTENSION file_fdw; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION file_fdw IS 'foreign-data wrapper for flat file access';


--
-- Name: pg_stat_monitor; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_monitor WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_monitor; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pg_stat_monitor IS 'The pg_stat_monitor is a PostgreSQL Query Performance Monitoring tool, based on PostgreSQL contrib module pg_stat_statements. pg_stat_monitor provides aggregated statistics, client information, plan details including plan, and histogram information.';


--
-- Name: log_server; Type: SERVER; Schema: -; Owner: postgres
--

CREATE SERVER log_server FOREIGN DATA WRAPPER file_fdw;


ALTER SERVER log_server OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categories; Type: TABLE; Schema: demo_schema_1; Owner: postgres
--

CREATE TABLE demo_schema_1.categories (
    id integer NOT NULL,
    name text
);


ALTER TABLE demo_schema_1.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: demo_schema_1; Owner: postgres
--

CREATE SEQUENCE demo_schema_1.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_1.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_1; Owner: postgres
--

ALTER SEQUENCE demo_schema_1.categories_id_seq OWNED BY demo_schema_1.categories.id;


--
-- Name: logs; Type: TABLE; Schema: demo_schema_1; Owner: postgres
--

CREATE TABLE demo_schema_1.logs (
    id integer NOT NULL,
    message text,
    ts timestamp with time zone DEFAULT now()
);


ALTER TABLE demo_schema_1.logs OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: demo_schema_1; Owner: postgres
--

CREATE SEQUENCE demo_schema_1.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_1.logs_id_seq OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_1; Owner: postgres
--

ALTER SEQUENCE demo_schema_1.logs_id_seq OWNED BY demo_schema_1.logs.id;


--
-- Name: orders; Type: TABLE; Schema: demo_schema_1; Owner: postgres
--

CREATE TABLE demo_schema_1.orders (
    id integer NOT NULL,
    user_id integer,
    product_id integer,
    quantity integer
);


ALTER TABLE demo_schema_1.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: demo_schema_1; Owner: postgres
--

CREATE SEQUENCE demo_schema_1.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_1.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_1; Owner: postgres
--

ALTER SEQUENCE demo_schema_1.orders_id_seq OWNED BY demo_schema_1.orders.id;


--
-- Name: products; Type: TABLE; Schema: demo_schema_1; Owner: postgres
--

CREATE TABLE demo_schema_1.products (
    id integer NOT NULL,
    name text,
    price numeric
);


ALTER TABLE demo_schema_1.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: demo_schema_1; Owner: postgres
--

CREATE SEQUENCE demo_schema_1.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_1.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_1; Owner: postgres
--

ALTER SEQUENCE demo_schema_1.products_id_seq OWNED BY demo_schema_1.products.id;


--
-- Name: users; Type: TABLE; Schema: demo_schema_1; Owner: postgres
--

CREATE TABLE demo_schema_1.users (
    id integer NOT NULL,
    name text
);


ALTER TABLE demo_schema_1.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: demo_schema_1; Owner: postgres
--

CREATE SEQUENCE demo_schema_1.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_1.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_1; Owner: postgres
--

ALTER SEQUENCE demo_schema_1.users_id_seq OWNED BY demo_schema_1.users.id;


--
-- Name: categories; Type: TABLE; Schema: demo_schema_2; Owner: postgres
--

CREATE TABLE demo_schema_2.categories (
    id integer NOT NULL,
    name text
);


ALTER TABLE demo_schema_2.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: demo_schema_2; Owner: postgres
--

CREATE SEQUENCE demo_schema_2.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_2.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_2; Owner: postgres
--

ALTER SEQUENCE demo_schema_2.categories_id_seq OWNED BY demo_schema_2.categories.id;


--
-- Name: logs; Type: TABLE; Schema: demo_schema_2; Owner: postgres
--

CREATE TABLE demo_schema_2.logs (
    id integer NOT NULL,
    message text,
    ts timestamp with time zone DEFAULT now()
);


ALTER TABLE demo_schema_2.logs OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: demo_schema_2; Owner: postgres
--

CREATE SEQUENCE demo_schema_2.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_2.logs_id_seq OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_2; Owner: postgres
--

ALTER SEQUENCE demo_schema_2.logs_id_seq OWNED BY demo_schema_2.logs.id;


--
-- Name: orders; Type: TABLE; Schema: demo_schema_2; Owner: postgres
--

CREATE TABLE demo_schema_2.orders (
    id integer NOT NULL,
    user_id integer,
    product_id integer,
    quantity integer
);


ALTER TABLE demo_schema_2.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: demo_schema_2; Owner: postgres
--

CREATE SEQUENCE demo_schema_2.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_2.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_2; Owner: postgres
--

ALTER SEQUENCE demo_schema_2.orders_id_seq OWNED BY demo_schema_2.orders.id;


--
-- Name: products; Type: TABLE; Schema: demo_schema_2; Owner: postgres
--

CREATE TABLE demo_schema_2.products (
    id integer NOT NULL,
    name text,
    price numeric
);


ALTER TABLE demo_schema_2.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: demo_schema_2; Owner: postgres
--

CREATE SEQUENCE demo_schema_2.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_2.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_2; Owner: postgres
--

ALTER SEQUENCE demo_schema_2.products_id_seq OWNED BY demo_schema_2.products.id;


--
-- Name: users; Type: TABLE; Schema: demo_schema_2; Owner: postgres
--

CREATE TABLE demo_schema_2.users (
    id integer NOT NULL,
    name text
);


ALTER TABLE demo_schema_2.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: demo_schema_2; Owner: postgres
--

CREATE SEQUENCE demo_schema_2.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_2.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_2; Owner: postgres
--

ALTER SEQUENCE demo_schema_2.users_id_seq OWNED BY demo_schema_2.users.id;


--
-- Name: categories; Type: TABLE; Schema: demo_schema_3; Owner: postgres
--

CREATE TABLE demo_schema_3.categories (
    id integer NOT NULL,
    name text
);


ALTER TABLE demo_schema_3.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: demo_schema_3; Owner: postgres
--

CREATE SEQUENCE demo_schema_3.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_3.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_3; Owner: postgres
--

ALTER SEQUENCE demo_schema_3.categories_id_seq OWNED BY demo_schema_3.categories.id;


--
-- Name: logs; Type: TABLE; Schema: demo_schema_3; Owner: postgres
--

CREATE TABLE demo_schema_3.logs (
    id integer NOT NULL,
    message text,
    ts timestamp with time zone DEFAULT now()
);


ALTER TABLE demo_schema_3.logs OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: demo_schema_3; Owner: postgres
--

CREATE SEQUENCE demo_schema_3.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_3.logs_id_seq OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_3; Owner: postgres
--

ALTER SEQUENCE demo_schema_3.logs_id_seq OWNED BY demo_schema_3.logs.id;


--
-- Name: orders; Type: TABLE; Schema: demo_schema_3; Owner: postgres
--

CREATE TABLE demo_schema_3.orders (
    id integer NOT NULL,
    user_id integer,
    product_id integer,
    quantity integer
);


ALTER TABLE demo_schema_3.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: demo_schema_3; Owner: postgres
--

CREATE SEQUENCE demo_schema_3.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_3.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_3; Owner: postgres
--

ALTER SEQUENCE demo_schema_3.orders_id_seq OWNED BY demo_schema_3.orders.id;


--
-- Name: products; Type: TABLE; Schema: demo_schema_3; Owner: postgres
--

CREATE TABLE demo_schema_3.products (
    id integer NOT NULL,
    name text,
    price numeric
);


ALTER TABLE demo_schema_3.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: demo_schema_3; Owner: postgres
--

CREATE SEQUENCE demo_schema_3.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_3.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_3; Owner: postgres
--

ALTER SEQUENCE demo_schema_3.products_id_seq OWNED BY demo_schema_3.products.id;


--
-- Name: users; Type: TABLE; Schema: demo_schema_3; Owner: postgres
--

CREATE TABLE demo_schema_3.users (
    id integer NOT NULL,
    name text
);


ALTER TABLE demo_schema_3.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: demo_schema_3; Owner: postgres
--

CREATE SEQUENCE demo_schema_3.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_3.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_3; Owner: postgres
--

ALTER SEQUENCE demo_schema_3.users_id_seq OWNED BY demo_schema_3.users.id;


--
-- Name: categories; Type: TABLE; Schema: demo_schema_4; Owner: postgres
--

CREATE TABLE demo_schema_4.categories (
    id integer NOT NULL,
    name text
);


ALTER TABLE demo_schema_4.categories OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: demo_schema_4; Owner: postgres
--

CREATE SEQUENCE demo_schema_4.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_4.categories_id_seq OWNER TO postgres;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_4; Owner: postgres
--

ALTER SEQUENCE demo_schema_4.categories_id_seq OWNED BY demo_schema_4.categories.id;


--
-- Name: logs; Type: TABLE; Schema: demo_schema_4; Owner: postgres
--

CREATE TABLE demo_schema_4.logs (
    id integer NOT NULL,
    message text,
    ts timestamp with time zone DEFAULT now()
);


ALTER TABLE demo_schema_4.logs OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE; Schema: demo_schema_4; Owner: postgres
--

CREATE SEQUENCE demo_schema_4.logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_4.logs_id_seq OWNER TO postgres;

--
-- Name: logs_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_4; Owner: postgres
--

ALTER SEQUENCE demo_schema_4.logs_id_seq OWNED BY demo_schema_4.logs.id;


--
-- Name: orders; Type: TABLE; Schema: demo_schema_4; Owner: postgres
--

CREATE TABLE demo_schema_4.orders (
    id integer NOT NULL,
    user_id integer,
    product_id integer,
    quantity integer
);


ALTER TABLE demo_schema_4.orders OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: demo_schema_4; Owner: postgres
--

CREATE SEQUENCE demo_schema_4.orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_4.orders_id_seq OWNER TO postgres;

--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_4; Owner: postgres
--

ALTER SEQUENCE demo_schema_4.orders_id_seq OWNED BY demo_schema_4.orders.id;


--
-- Name: products; Type: TABLE; Schema: demo_schema_4; Owner: postgres
--

CREATE TABLE demo_schema_4.products (
    id integer NOT NULL,
    name text,
    price numeric
);


ALTER TABLE demo_schema_4.products OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: demo_schema_4; Owner: postgres
--

CREATE SEQUENCE demo_schema_4.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_4.products_id_seq OWNER TO postgres;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_4; Owner: postgres
--

ALTER SEQUENCE demo_schema_4.products_id_seq OWNED BY demo_schema_4.products.id;


--
-- Name: users; Type: TABLE; Schema: demo_schema_4; Owner: postgres
--

CREATE TABLE demo_schema_4.users (
    id integer NOT NULL,
    name text
);


ALTER TABLE demo_schema_4.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: demo_schema_4; Owner: postgres
--

CREATE SEQUENCE demo_schema_4.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE demo_schema_4.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: demo_schema_4; Owner: postgres
--

ALTER SEQUENCE demo_schema_4.users_id_seq OWNED BY demo_schema_4.users.id;


--
-- Name: pg_stat_monitor_mock; Type: TABLE; Schema: public; Owner: Santix
--

CREATE TABLE public.pg_stat_monitor_mock (
    bucket_start_time timestamp with time zone NOT NULL,
    queryid text,
    query text,
    calls bigint,
    total_exec_time double precision,
    mean_exec_time double precision,
    max_exec_time double precision,
    min_exec_time double precision,
    rows bigint,
    error_code text,
    error_message text,
    plan text
);


ALTER TABLE public.pg_stat_monitor_mock OWNER TO "Santix";

--
-- Name: test; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test (
    x integer
);


ALTER TABLE public.test OWNER TO postgres;

--
-- Name: test_hist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.test_hist (
    x integer
);


ALTER TABLE public.test_hist OWNER TO postgres;

--
-- Name: categories id; Type: DEFAULT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.categories ALTER COLUMN id SET DEFAULT nextval('demo_schema_1.categories_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.logs ALTER COLUMN id SET DEFAULT nextval('demo_schema_1.logs_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.orders ALTER COLUMN id SET DEFAULT nextval('demo_schema_1.orders_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.products ALTER COLUMN id SET DEFAULT nextval('demo_schema_1.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.users ALTER COLUMN id SET DEFAULT nextval('demo_schema_1.users_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.categories ALTER COLUMN id SET DEFAULT nextval('demo_schema_2.categories_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.logs ALTER COLUMN id SET DEFAULT nextval('demo_schema_2.logs_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.orders ALTER COLUMN id SET DEFAULT nextval('demo_schema_2.orders_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.products ALTER COLUMN id SET DEFAULT nextval('demo_schema_2.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.users ALTER COLUMN id SET DEFAULT nextval('demo_schema_2.users_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.categories ALTER COLUMN id SET DEFAULT nextval('demo_schema_3.categories_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.logs ALTER COLUMN id SET DEFAULT nextval('demo_schema_3.logs_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.orders ALTER COLUMN id SET DEFAULT nextval('demo_schema_3.orders_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.products ALTER COLUMN id SET DEFAULT nextval('demo_schema_3.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.users ALTER COLUMN id SET DEFAULT nextval('demo_schema_3.users_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.categories ALTER COLUMN id SET DEFAULT nextval('demo_schema_4.categories_id_seq'::regclass);


--
-- Name: logs id; Type: DEFAULT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.logs ALTER COLUMN id SET DEFAULT nextval('demo_schema_4.logs_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.orders ALTER COLUMN id SET DEFAULT nextval('demo_schema_4.orders_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.products ALTER COLUMN id SET DEFAULT nextval('demo_schema_4.products_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.users ALTER COLUMN id SET DEFAULT nextval('demo_schema_4.users_id_seq'::regclass);


--
-- Data for Name: categories; Type: TABLE DATA; Schema: demo_schema_1; Owner: postgres
--

COPY demo_schema_1.categories (id, name) FROM stdin;
1	category_1
2	category_2
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: demo_schema_1; Owner: postgres
--

COPY demo_schema_1.logs (id, message, ts) FROM stdin;
1	system started	2025-12-01 14:08:39.928287-03
2	user logged in	2025-12-01 14:08:39.928287-03
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: demo_schema_1; Owner: postgres
--

COPY demo_schema_1.orders (id, user_id, product_id, quantity) FROM stdin;
1	1	1	5
2	2	2	1
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: demo_schema_1; Owner: postgres
--

COPY demo_schema_1.products (id, name, price) FROM stdin;
1	product_x	9.99
2	product_y	49.50
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: demo_schema_1; Owner: postgres
--

COPY demo_schema_1.users (id, name) FROM stdin;
1	user_a
2	user_b
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: demo_schema_2; Owner: postgres
--

COPY demo_schema_2.categories (id, name) FROM stdin;
1	category_1
2	category_2
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: demo_schema_2; Owner: postgres
--

COPY demo_schema_2.logs (id, message, ts) FROM stdin;
1	system started	2025-12-01 14:08:39.928287-03
2	user logged in	2025-12-01 14:08:39.928287-03
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: demo_schema_2; Owner: postgres
--

COPY demo_schema_2.orders (id, user_id, product_id, quantity) FROM stdin;
1	1	1	5
2	2	2	1
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: demo_schema_2; Owner: postgres
--

COPY demo_schema_2.products (id, name, price) FROM stdin;
1	product_x	9.99
2	product_y	49.50
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: demo_schema_2; Owner: postgres
--

COPY demo_schema_2.users (id, name) FROM stdin;
1	user_a
2	user_b
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: demo_schema_3; Owner: postgres
--

COPY demo_schema_3.categories (id, name) FROM stdin;
1	category_1
2	category_2
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: demo_schema_3; Owner: postgres
--

COPY demo_schema_3.logs (id, message, ts) FROM stdin;
1	system started	2025-12-01 14:08:39.928287-03
2	user logged in	2025-12-01 14:08:39.928287-03
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: demo_schema_3; Owner: postgres
--

COPY demo_schema_3.orders (id, user_id, product_id, quantity) FROM stdin;
1	1	1	5
2	2	2	1
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: demo_schema_3; Owner: postgres
--

COPY demo_schema_3.products (id, name, price) FROM stdin;
1	product_x	9.99
2	product_y	49.50
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: demo_schema_3; Owner: postgres
--

COPY demo_schema_3.users (id, name) FROM stdin;
1	user_a
2	user_b
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: demo_schema_4; Owner: postgres
--

COPY demo_schema_4.categories (id, name) FROM stdin;
1	category_1
2	category_2
\.


--
-- Data for Name: logs; Type: TABLE DATA; Schema: demo_schema_4; Owner: postgres
--

COPY demo_schema_4.logs (id, message, ts) FROM stdin;
1	system started	2025-12-01 14:08:39.928287-03
2	user logged in	2025-12-01 14:08:39.928287-03
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: demo_schema_4; Owner: postgres
--

COPY demo_schema_4.orders (id, user_id, product_id, quantity) FROM stdin;
1	1	1	5
2	2	2	1
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: demo_schema_4; Owner: postgres
--

COPY demo_schema_4.products (id, name, price) FROM stdin;
1	product_x	9.99
2	product_y	49.50
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: demo_schema_4; Owner: postgres
--

COPY demo_schema_4.users (id, name) FROM stdin;
1	user_a
2	user_b
\.


--
-- Data for Name: pg_stat_monitor_mock; Type: TABLE DATA; Schema: public; Owner: Santix
--

COPY public.pg_stat_monitor_mock (bucket_start_time, queryid, query, calls, total_exec_time, mean_exec_time, max_exec_time, min_exec_time, rows, error_code, error_message, plan) FROM stdin;
2025-08-16 00:05:35.154367-03	12345	SELECT * FROM users WHERE last_name = $1	10	5000.12	500.01	800.5	200.1	100	\N	\N	Seq Scan on users
2025-08-16 00:04:35.154367-03	67890	SELECT p.product_name, c.category_name FROM products p JOIN categories c ON p.category_id = c.id	5	3500.45	700.09	900	450.2	50	\N	\N	Hash Join
2025-08-16 00:06:35.154367-03	ABCDE	SELECT 1	1500	150	0.1	1	0.05	1500	\N	\N	Result
2025-08-16 00:03:35.154367-03	FGHIJ	UPDATE sessions SET last_seen = now() WHERE id = $1	800	80	0.1	0.5	0.05	800	\N	\N	Index Scan using sessions_pkey
2025-08-16 00:02:35.154367-03	KLMNO	SELECT * FROM big_table WHERE description LIKE $1	2	6000	3000	4000	2000	2	\N	\N	Seq Scan on big_table
2025-08-16 00:01:35.154367-03	UVWXY	SELECT * FROM non_existent_table	20	5	0.25	0.3	0.2	0	42P01	relation "non_existent_table" does not exist	\N
2025-08-16 00:06:35.154367-03	PLANID1	SELECT * FROM users WHERE id = $1	100	25	0.25	1	0.1	100	\N	\N	\nIndex Scan using users_pkey on users (cost=0.29..8.31 rows=1 width=104)\n  Index Cond: (id = 1)\n
\.


--
-- Data for Name: test; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test (x) FROM stdin;
1
2
3
\.


--
-- Data for Name: test_hist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.test_hist (x) FROM stdin;
1
2
3
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: demo_schema_1; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_1.categories_id_seq', 3, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: demo_schema_1; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_1.logs_id_seq', 4, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: demo_schema_1; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_1.orders_id_seq', 4, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: demo_schema_1; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_1.products_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: demo_schema_1; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_1.users_id_seq', 4, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: demo_schema_2; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_2.categories_id_seq', 2, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: demo_schema_2; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_2.logs_id_seq', 2, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: demo_schema_2; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_2.orders_id_seq', 2, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: demo_schema_2; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_2.products_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: demo_schema_2; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_2.users_id_seq', 2, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: demo_schema_3; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_3.categories_id_seq', 2, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: demo_schema_3; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_3.logs_id_seq', 2, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: demo_schema_3; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_3.orders_id_seq', 2, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: demo_schema_3; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_3.products_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: demo_schema_3; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_3.users_id_seq', 2, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: demo_schema_4; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_4.categories_id_seq', 2, true);


--
-- Name: logs_id_seq; Type: SEQUENCE SET; Schema: demo_schema_4; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_4.logs_id_seq', 2, true);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: demo_schema_4; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_4.orders_id_seq', 2, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: demo_schema_4; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_4.products_id_seq', 2, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: demo_schema_4; Owner: postgres
--

SELECT pg_catalog.setval('demo_schema_4.users_id_seq', 2, true);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: demo_schema_1; Owner: postgres
--

ALTER TABLE ONLY demo_schema_1.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: demo_schema_2; Owner: postgres
--

ALTER TABLE ONLY demo_schema_2.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: demo_schema_3; Owner: postgres
--

ALTER TABLE ONLY demo_schema_3.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: logs logs_pkey; Type: CONSTRAINT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.logs
    ADD CONSTRAINT logs_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: demo_schema_4; Owner: postgres
--

ALTER TABLE ONLY demo_schema_4.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict Ilhv5fbtvYLkCSY5yUihe2V8CHar1HxJEAAMc0CLXhihLnNdjbU6YbA25OPoYCW

